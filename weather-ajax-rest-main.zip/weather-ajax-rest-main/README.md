# Weather-App-Using-Ajax
Open weather map API provides current weather data, weather forecast data as well as historical weather data.
With our application, we will make API calls by city name to the open weather map API using Ajax to get response in JSON format.

The weather app will be used to:
Get current weather information like temperature, pressure, humidity, wind speed, wind direction etc.
Get weather forecast information of any city by city name and number of days.
Features:
Make API calls with Ajax.
Open weather map API description.
Get current weather information.
Get weather forecast information.
Use jquery plugin to animate text.
